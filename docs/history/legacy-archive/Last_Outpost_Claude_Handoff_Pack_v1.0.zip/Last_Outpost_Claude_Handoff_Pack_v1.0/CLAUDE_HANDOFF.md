# LAST OUTPOST — CLAUDE HANDOFF PACK v1.0

## Mục đích
Đây là bộ quy tắc bàn giao từ design sang Claude implementation.

Claude:
- đọc design;
- triển khai theo scope;
- giữ nguyên intent;
- đề xuất thay đổi khi cần;
- không tự ý redesign core game.

## Core identity
**Stylized 2.5D Cartoon + Post-Apocalyptic Adventure + Tactical Strategy**

Core loop:
**BUILD → PREPARE → SURVIVE → ADAPT → GROW → TRY AGAIN**

## Non-negotiable
1. Outpost progression là persistent, không reset theo season thông thường.
2. Mỗi mission có Fixed Enemy Roster.
3. Mỗi mission mục tiêu 5–15 phút.
4. Tower = Base + Barrel + Module.
5. Counterplay quan trọng hơn raw stat.
6. Boss không phải HP sponge.
7. Cartoon thân thiện nhưng không full chibi.
8. Battlefield readability cao hơn visual spectacle.
9. UI không thành generic mobile card RPG.
10. Free vẫn chơi được core game.
11. Plus/Pro chỉ tạo lợi thế giới hạn theo design.
12. PvP cạnh tranh cần normalization/giới hạn stat nhạy cảm.
13. Save/progression phải recovery-safe.
14. Content phải data-driven.

## Vertical Slice target
- 1 Outpost
- 1 biome: Ruined City
- 1 chapter
- 5 missions
- 6 core Tower/build archetypes
- 1 Commander: Engineer
- Fixed rosters
- 1 Boss: Colossus Titan
- Full flow: Outpost → Briefing → Loadout → Prepare → Combat → Result → Reward → Upgrade → Outpost Growth

## Mission targets
- M01: Crawler, 5–7 phút
- M02: Crawler + Acid Bloater, 6–8 phút
- M03: Crawler + Iron-Hide Behemoth, 7–10 phút
- M04: Crawler + Acid Bloater + EMP Stalker, 8–11 phút
- M05: Crawler + Iron-Hide Behemoth + Siren Screamer + Colossus Titan, 10–15 phút

## Implementation priority
### P0
BattleWorld, fixed tick, Tower, Enemy, damage, wave, objectives, renderer, input.

### P1
Status, targeting, pathfinding, logistics, heat/power/water, hazards, Commander, pooling, spatial query, AI LOD.

### P2
Outpost, progression, economy, save, cloud sync, entitlement, season, analytics.

### P3
Guild, PvP, advanced live systems.

## Terminology
Resources: Scrap, Materials, Blueprint Fragment, Biomass, Rad-Gems, Ammo, Power, Water.

Combat: Tower, Base, Barrel, Module, Commander, Wave, Threat Budget, Fixed Roster, Hazard, Objective, Mastery.

Progression: Outpost, Tech Tree, Blueprint, Expedition, Season, Plus, Pro.

## Visual rules
Must: stylized, 2.5D, expressive, chunky, readable, scrap-tech, friendly apocalypse.
Avoid: photorealistic, grimdark, full chibi, fantasy magic, generic mobile RPG, excessive glassmorphism, gore/horror-first.

## UX rule
**SEE → UNDERSTAND → DECIDE → ACT → FEEDBACK → LEARN → GROW**

## Data/economy rule
Reward flow:
Combat Result → Validate → Reward Calculate → Transaction → Commit → Confirm → UI

Client/UI must not directly award premium currency or competitive rewards.

## Deviation policy
Any player-facing or system-level deviation must record:
- Design Rule
- Reason
- Technical Constraint
- Proposed Alternative
- Gameplay Impact
- Data/Save Impact
- Approval needed

## Final rule
> Claude implements the game described by the documents; Claude does not silently become the game designer.
