# LAST OUTPOST — CURRENT DECISIONS

- Visual: Stylized 2.5D Cartoon + Post-Apocalyptic Adventure + Tactical Strategy.
- Battle duration: 5–15 minutes.
- Enemy selection: Fixed roster per mission.
- Outpost: persistent; ordinary seasons do not reset it.
- Tower: Base + Barrel + Module.
- Progression: Outpost + Tech Tree + Mastery + Blueprint.
- Monetization: Free / Plus / Pro; limited PvE tactical advantages; competitive normalization.
- Guild/PvP: simplified and lower priority than PvE core.
- Design role: documents, systems, content, UX/UI, visual references.
- Claude role: implementation/code after design handoff.
- First implementation target: Vertical Slice before large-scale content.
